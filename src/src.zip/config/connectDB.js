const mysql = require('mysql2/promise');

const connection = mysql.createPool({
    host: 'localhost',
    user: 'winsure',
    password: 'winsure',
    database: 'winsure',
});

export default connection;